package com.deloitte;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JioMartOrderMicroservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
