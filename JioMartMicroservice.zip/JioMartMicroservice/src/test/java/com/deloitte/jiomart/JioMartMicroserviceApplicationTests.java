package com.deloitte.jiomart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JioMartMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
