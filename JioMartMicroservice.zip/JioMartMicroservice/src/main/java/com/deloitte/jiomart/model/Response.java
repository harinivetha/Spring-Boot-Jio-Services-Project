package com.deloitte.jiomart.model;

import java.util.List;

import com.deloitte.jiomart.entity.JioMart;

public class Response {
	
	private JioMart jiom;
	private List<Order> orders;
	
	public Response(JioMart jiom) {
		super();
		this.jiom = jiom;
	}
	public Response() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Response(JioMart jiom, List<Order> orders) {
		super();
		this.jiom = jiom;
		this.orders = orders;
	}
	public JioMart getJiom() {
		return jiom;
	}
	public void setJiom(JioMart jiom) {
		this.jiom = jiom;
	}
	public List<Order> getOrders() {
		return orders;
	}
	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}
	
	

}
