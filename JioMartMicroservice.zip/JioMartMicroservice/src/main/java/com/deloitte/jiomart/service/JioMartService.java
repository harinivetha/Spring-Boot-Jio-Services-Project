package com.deloitte.jiomart.service;

import java.util.List;

import com.deloitte.jiomart.entity.JioMart;

public interface JioMartService {

	public JioMart getProduct(Integer id);
	public List<JioMart> getProducts();
	
	
	
}
